readme.txt
----------
Example make file with Eclipse (MCUXpresso IDE).
This project uses the FRDM-KL25Z as example.

See: https://mcuoneclipse.com/2017/07/22/tutorial-makefile-projects-with-eclipse/

See as well the following make file:
https://github.com/Muriukidavid/twr-k60n512_2017/blob/master/Makefile
