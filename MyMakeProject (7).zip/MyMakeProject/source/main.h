/*
 * main.h
 *
 *  Created on: 22.07.2017
 *      Author: Erich Styger Local
 */

#ifndef SOURCE_MAIN_H_
#define SOURCE_MAIN_H_



#endif /* SOURCE_MAIN_H_ */
